# data-story-example

This repository hosts an example that shows the format of the data story for the information visualization course at the Informatics Institute, University of Amsterdam.

Credit: the format example is originally created by [Roan van Blanken](https://github.com/roanvanblanken) and later edited by [Yen-Chia Hsu](https://github.com/yenchiah).
